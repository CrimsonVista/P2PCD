Catch2 testing for Veins
------------------------

Import this as a project into the OMNeT++ IDE or build on the command line (./configure; make).
Run ./src/veins_catch to execute all tests.
