// This builds the main binary that will execute all tests.
// Do not modify this file. Rather, add new .cc files in this directory.
#define CATCH_CONFIG_MAIN
#include "catch/catch.hpp"
